# Options

Any specified option will be passed through directly to [JSHint][], thus you can specify any option that JSHint supports. See the [JSHint documentation][] for a list of supported options.

[JSHint]: http://jshint.com/
[JSHint documentation]: http://jshint.com/docs/

A few additional options are supported:


## globals

Type: `Object`  
Default: `null`

A map of global variables, with keys as names and a boolean value to determine if they are assignable. This is not a standard JSHint option, but is passed into the `JSHINT` function as its third argument. See the [JSHint documentation][] for more information.


## jshintrc

Type: `String` or `true`  
Default: `null`

If set to `true`, no config will be sent to JSHint and JSHint will search for `.jshintrc` files relative to the files being linted.

If a filename is specified, options and globals defined therein will be used. The `jshintrc` file must be valid JSON and looks something like this:

```json
{
  "curly": true,
  "eqnull": true,
  "eqeqeq": true,
  "undef": true,
  "globals": {
    "jQuery": true
  }
}
```

*Be aware that `jshintrc` settings are not merged with your Grunt options.*


## extensions

Type: `String`  
Default: `''`

A list of non-dot-js extensions to check.


## ignores

Type: `Array`  
Default: `null`

A list of files and dirs to ignore. This will override your `.jshintignore` file if set and does not merge.


## force

Type: `Boolean`  
Default: `false`

Set `force` to `true` to report JSHint errors but not fail the task.


## reporter

Type: `String`  
Default: `null`

Allows you to modify this plugins output. By default it will use a built-in Grunt reporter. Set the path to your own custom reporter or to one of the built-in JSHint reporters: `jslint` or `checkstyle`.

See also: [Writing your own JSHint reporter.](http://jshint.com/docs/reporters/)

You can also use an external reporter. For example [jshint-stylish](https://github.com/sindresorhus/jshint-stylish):

```
$ npm install --save-dev jshint-stylish
```

```js
options: {
    reporter: require('jshint-stylish')
}
```

## reporterOutput

Type: `String`  
Default: `null`

Specify a filepath  to output the results of a reporter. If `reporterOutput` is specified then all output will be written to the given filepath instead of printed to stdout.

#### reporterOutputRelative

Type: `Boolean`  
Default: `true`

Results of a reporter will use a relative filepath to `reporterOutput`.  If set to `false` then filepaths will appear relative to the current folder.  Unless `reporterOutput` is not set this option will not have any effect.
