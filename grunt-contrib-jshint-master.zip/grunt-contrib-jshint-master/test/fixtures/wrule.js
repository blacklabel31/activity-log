// throws "not defined" errors,
// but we are testing to make sure we can ignore that warning by code.
something = '';
